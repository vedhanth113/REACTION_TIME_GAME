
import tkinter as tk
import random
import time

class TypingSpeedGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Reaction and Typing Speed Game")
        self.root.geometry("400x300")
        
        self.challenge = ""
        self.start_time = 0
        
        # Widgets
        self.label = tk.Label(root, text="Click Start to Play!", font=("Arial", 14))
        self.label.pack(pady=20)
        
        self.entry = tk.Entry(root, font=("Arial", 14), state="disabled")
        self.entry.pack(pady=10)
        self.entry.bind("<Return>", self.check_input)
        
        self.start_button = tk.Button(root, text="Start", font=("Arial", 12), command=self.start_game)
        self.start_button.pack(pady=10)
        
        self.result_label = tk.Label(root, text="", font=("Arial", 12))
        self.result_label.pack(pady=20)
        
        self.play_again_button = tk.Button(root, text="Play Again", font=("Arial", 12), state="disabled", command=self.start_game)
        self.play_again_button.pack(pady=10)
    
    def generate_random_challenge(self):
        options = ["word", "number"]
        choice = random.choice(options)
        if choice == "word":
            words = ["python", "reaction", "speed", "challenge", "typing", "game"]
            return random.choice(words)
        else:
            return str(random.randint(100, 999))
    
    def start_game(self):
        self.challenge = self.generate_random_challenge()
        self.result_label.config(text="")
        self.entry.config(state="normal")
        self.entry.delete(0, tk.END)
        self.entry.focus()
        
        self.start_button.config(state="disabled")
        self.play_again_button.config(state="disabled")
        
        delay = random.uniform(2, 5)
        self.root.after(int(delay * 1000), self.show_challenge)
    
    def show_challenge(self):
        self.label.config(text=f"Type this: {self.challenge}")
        self.start_time = time.time()
    
    def check_input(self, event):
        user_input = self.entry.get()
        end_time = time.time()
        
        reaction_time = end_time - self.start_time
        typing_time = reaction_time  # Adjust typing calculation if more precise tracking is needed.
        
        if user_input == self.challenge:
            self.result_label.config(
                text=f"Success! Reaction: {reaction_time:.3f}s"
            )
        else:
            self.result_label.config(text=f"Oops! Correct was: {self.challenge}")
        
        self.start_button.config(state="normal")
        self.play_again_button.config(state="normal")
        self.entry.config(state="disabled")

# Run the game
if __name__ == "__main__":
    root = tk.Tk()
    game = TypingSpeedGame(root)
    root.mainloop()
